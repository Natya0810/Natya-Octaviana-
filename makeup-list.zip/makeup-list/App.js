import React, { useState, useEffect } from 'react';
import { View, FlatList, StyleSheet, Image } from 'react-native';
import { BottomNavigation, Appbar, Searchbar, FAB, Card, Title } from 'react-native-paper';

const MakeupList = ({ navigation }) => {
  const [makeupItems, setMakeupItems] = useState([
    { id: '1', name: 'Lipstick', image: 'https://example.com/lipstick.png' },
    { id: '2', name: 'Foundation', image: 'https://example.com/foundation.png' },
    { id: '3', name: 'Mascara', image: 'https://example.com/mascara.png' },
    { id: '4', name: 'Blush', image: 'https://example.com/blush.png' },
    { id: '5', name: 'Eyeliner', image: 'https://example.com/eyeliner.png' },
    { id: '6', name: 'Concealer', image: 'https://example.com/concealer.png' },
    { id: '7', name: 'Powder', image: 'https://example.com/powder.png' },
    { id: '8', name: 'Highlighter', image: 'https://example.com/highlighter.png' },
    { id: '9', name: 'Bronzer', image: 'https://example.com/bronzer.png' },
    { id: '10', name: 'Eyeshadow', image: 'https://example.com/eyeshadow.png' },
    { id: '11', name: 'Lip Gloss', image: 'https://example.com/lipgloss.png' },
    { id: '12', name: 'Setting Spray', image: 'https://example.com/settingspray.png' },
    { id: '13', name: 'Primer', image: 'https://example.com/primer.png' },
    { id: '14', name: 'Lip Liner', image: 'https://example.com/lipliner.png' },
    { id: '15', name: 'Brow Gel', image: 'https://example.com/browgel.png' },
    { id: '16', name: 'Contour', image: 'https://example.com/contour.png' },
    { id: '17', name: 'BB Cream', image: 'https://example.com/bbcream.png' },
    { id: '18', name: 'CC Cream', image: 'https://example.com/cccream.png' },
    { id: '19', name: 'Tinted Moisturizer', image: 'https://example.com/tintedmoisturizer.png' },
    { id: '20', name: 'Setting Powder', image: 'https://example.com/settingpowder.png' },
    { id: '21', name: 'Face Mist', image: 'https://example.com/facemist.png' },
    { id: '22', name: 'Lip Balm', image: 'https://example.com/lipbalm.png' },
    { id: '23', name: 'Lip Stain', image: 'https://example.com/lipstain.png' },
    { id: '24', name: 'Face Serum', image: 'https://example.com/faceserum.png' },
    { id: '25', name: 'Face Oil', image: 'https://example.com/faceoil.png' },
    { id: '26', name: 'Face Primer', image: 'https://example.com/faceprimer.png' },
    { id: '27', name: 'Eyelash Curler', image: 'https://example.com/eyelashcurler.png' },
    { id: '28', name: 'Eye Primer', image: 'https://example.com/eyeprimer.png' },
    { id: '29', name: 'Brow Pencil', image: 'https://example.com/browpencil.png' },
    { id: '30', name: 'Brow Powder', image: 'https://example.com/browpowder.png' },
  ]);

  const [searchQuery, setSearchQuery] = useState('');
  const [filteredMakeupItems, setFilteredMakeupItems] = useState(makeupItems);

  useEffect(() => {
    setFilteredMakeupItems(
      makeupItems.filter(item =>
        item.name.toLowerCase().includes(searchQuery.toLowerCase())
      )
    );
  }, [searchQuery, makeupItems]);

  return (
    <View style={styles.container}>
      <Appbar.Header>
        <Appbar.Content title="Makeup List" />
      </Appbar.Header>
      <Searchbar
        placeholder="Search"
        onChangeText={setSearchQuery}
        value={searchQuery}
        style={styles.searchbar}
      />
      <FlatList
        data={filteredMakeupItems}
        keyExtractor={(item) => item.id}
        renderItem={({ item }) => (
          <Card style={styles.card}>
            <Card.Content style={styles.cardContent}>
              <Image source={{ uri: item.image }} style={styles.image} />
              <View style={styles.textContainer}>
                <Title>{item.name}</Title>
              </View>
            </Card.Content>
          </Card>
        )}
      />
      <FAB
        style={styles.fab}
        small
        icon="plus"
        onPress={() => navigation.navigate('AddMakeup', { addMakeup: (item) => setMakeupItems([...makeupItems, item]) })}
      />
    </View>
  );
};

const HomeRoute = () => (
  <View style={[styles.routeContainer, { backgroundColor: '#e0ffff' }]}>
    <Title>Home</Title>
  </View>
);

const MakeupListRoute = (props) => <MakeupList {...props} />;

export default function App() {
  const [index, setIndex] = useState(0);
  const [routes] = useState([
    { key: 'home', title: 'Home', icon: 'home' },
    { key: 'makeupList', title: 'Makeup List', icon: 'palette' },
  ]);

  const renderScene = BottomNavigation.SceneMap({
    home: HomeRoute,
    makeupList: MakeupListRoute,
  });

  return (
    <BottomNavigation
      navigationState={{ index, routes }}
      onIndexChange={setIndex}
      renderScene={renderScene}
    />
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#ffe4e1',
  },
  searchbar: {
    margin: 8,
    borderRadius: 8,
  },
  card: {
    margin: 8,
    backgroundColor: '#fff0f5',
    borderRadius: 8,
    elevation: 4,
  },
  cardContent: {
    flexDirection: 'row',
    alignItems: 'center',
  },
  image: {
    width: 50,
    height: 50,
    marginRight: 16,
  },
  textContainer: {
    flex: 1,
  },
  fab: {
    position: 'absolute',
    margin: 16,
    right: 0,
    bottom: 0,
    backgroundColor: '#ff69b4',
  },
  routeContainer: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
  },
});
