import React, { useState } from 'react';
import { View, FlatList, Button, StyleSheet } from 'react-native';
import { List, FAB } from 'react-native-paper';

export default function MakeupList({ navigation }) {
  const [makeupItems, setMakeupItems] = useState([
    { id: '1', name: 'Lipstick' },
    { id: '2', name: 'Foundation' },
    { id: '3', name: 'Mascara' },
  ]);

  return (
    <View style={styles.container}>
      <FlatList
        data={makeupItems}
        keyExtractor={(item) => item.id}
        renderItem={({ item }) => (
          <List.Item
            title={item.name}
            left={(props) => <List.Icon {...props} icon="makeup" />}
          />
        )}
      />
      <FAB
        style={styles.fab}
        small
        icon="plus"
        onPress={() => navigation.navigate('AddMakeup', { addMakeup: (item) => setMakeupItems([...makeupItems, item]) })}
      />
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#fff',
  },
  fab: {
    position: 'absolute',
    margin: 16,
    right: 0,
    bottom: 0,
  },
});
