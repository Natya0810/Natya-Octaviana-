import React, { useState } from 'react';
import { View, StyleSheet, TextInput, Button } from 'react-native';

export default function AddMakeup({ route, navigation }) {
  const [name, setName] = useState('');
  const { addMakeup } = route.params;

  const handleAdd = () => {
    const newMakeup = { id: Math.random().toString(), name };
    addMakeup(newMakeup);
    navigation.goBack();
  };

  return (
    <View style={styles.container}>
      <TextInput
        style={styles.input}
        placeholder="Makeup Name"
        value={name}
        onChangeText={setName}
      />
      <Button title="Add Makeup" onPress={handleAdd} />
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    padding: 16,
    backgroundColor: '#fff',
  },
  input: {
    height: 40,
    borderColor: 'gray',
    borderWidth: 1,
    marginBottom: 16,
    paddingLeft: 8,
  },
});
